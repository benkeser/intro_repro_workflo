# I am a fake R script
print("This is 00_example.R")

print("My current working directory is:")
getwd()