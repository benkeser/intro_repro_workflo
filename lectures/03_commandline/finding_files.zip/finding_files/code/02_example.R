# I am yet another fake R script
print("This is 02_example.R")

# I am adding lots of lines to this script




# to demonstrate less vs. cat




# but the lines are all comments




# so they don't really run any code





# that's probably enough lines now...




# you came all this way, let's print something
print("All done with 02_example.R")