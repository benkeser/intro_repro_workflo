# I am another fake R script
print("This is 01_example.R")